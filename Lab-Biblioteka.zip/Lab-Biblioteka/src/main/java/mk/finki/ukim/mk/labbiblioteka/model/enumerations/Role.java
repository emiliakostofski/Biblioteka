package mk.finki.ukim.mk.labbiblioteka.model.enumerations;

public enum Role {

    ROLE_USER, ROLE_ADMIN;

    //public String getAuthority() return name;
}
