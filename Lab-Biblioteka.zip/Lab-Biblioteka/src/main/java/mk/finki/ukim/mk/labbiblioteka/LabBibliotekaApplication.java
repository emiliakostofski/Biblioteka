package mk.finki.ukim.mk.labbiblioteka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LabBibliotekaApplication {

    public static void main(String[] args) {
        SpringApplication.run(LabBibliotekaApplication.class, args);
    }

}
