package mk.finki.ukim.mk.labbiblioteka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LabBibliotekaApplicationTests {

    @Test
    void contextLoads() {
    }

}
